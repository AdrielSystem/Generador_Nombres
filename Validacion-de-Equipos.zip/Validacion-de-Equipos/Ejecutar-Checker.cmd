@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Checker N1 - Coltefinanciera

set "PSEXEC=C:\Windows.old.000\PSTools\PsExec.exe"
set "SCRIPT=%~dp0Checker-PC.ps1"
set "CARPETA_REPORTES=%~dp0Reportes"
set "LISTA_EQUIPOS=%~dp0equipos.txt"

REM Prioridad: PsExec junto al CMD; luego la ruta corporativa configurada.
if exist "%~dp0PsExec.exe" set "PSEXEC=%~dp0PsExec.exe"

REM El acceso a ADMIN$ y la instalacion de PSEXESVC requieren elevacion.
fltmc >nul 2>&1
if errorlevel 1 (
    echo ERROR: Ejecute este archivo como administrador.
    echo Clic derecho sobre Ejecutar-Checker.cmd y seleccione
    echo "Ejecutar como administrador".
    pause
    exit /b 1
)

if not exist "%SCRIPT%" (
    echo ERROR: No se encontro el checker:
    echo %SCRIPT%
    pause
    exit /b 3
)

if not exist "%CARPETA_REPORTES%" mkdir "%CARPETA_REPORTES%"

REM Mantiene compatibilidad con: Ejecutar-Checker.cmd NOMBREPC
if not "%~1"=="" (
    set "PC=%~1"
    goto REMOTO
)

:MENU
cls
echo ============================================================
echo  CHECKER N1 - COLTEFINANCIERA
echo ============================================================
echo.
echo  [1] Validar este equipo ^(local^)
echo  [2] Validar otro equipo ^(PsExec^)
echo  [3] Despliegue masivo desde equipos.txt
echo  [4] Salir
echo.
choice /C 1234 /N /M "Seleccione una opcion [1-4]: "

if errorlevel 4 exit /b 0
if errorlevel 3 goto MASIVO
if errorlevel 2 goto PEDIR_PC
if errorlevel 1 goto LOCAL

:LOCAL
set "PC=%COMPUTERNAME%"
set "REPORTE=%CARPETA_REPORTES%\%PC%_Checker.txt"
set "REPORTE_HTML=%CARPETA_REPORTES%\%PC%_Checker.html"
cls
echo ============================================================
echo  CHECKER N1 - VALIDACION LOCAL
echo ============================================================
echo.
echo Equipo: %PC%
echo.
echo Ejecutando checker local...
echo.

set "CHECKER_SCRIPT=%SCRIPT%"
set "CHECKER_REPORT=%REPORTE%"
set "CHECKER_REPORT_HTML=%REPORTE_HTML%"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "& $env:CHECKER_SCRIPT -RutaReporteHtml $env:CHECKER_REPORT_HTML *>&1 | Tee-Object -FilePath $env:CHECKER_REPORT; exit $LASTEXITCODE"
set "RESULTADO=%ERRORLEVEL%"

if not "%RESULTADO%"=="0" (
    echo.
    echo ADVERTENCIA: PowerShell termino con el codigo %RESULTADO%.
)
goto FIN

:PEDIR_PC
cls
echo ============================================================
echo  CHECKER N1 - VALIDACION REMOTA
echo ============================================================
echo.
set "PC="
set /P "PC=Ingrese el nombre del equipo: "

if not defined PC (
    echo ERROR: Debe ingresar un nombre de equipo.
    timeout /t 2 >nul
    goto MENU
)

:REMOTO
call :VALIDAR_REMOTO "%PC%"
set "RESULTADO=%ERRORLEVEL%"
goto FIN

:MASIVO
cls
echo ============================================================
echo  CHECKER N1 - DESPLIEGUE MASIVO
echo ============================================================
echo.

if not exist "%LISTA_EQUIPOS%" (
    echo ERROR: No se encontro la lista:
    echo %LISTA_EQUIPOS%
    echo.
    echo Cree equipos.txt junto al CMD, con un equipo por linea.
    pause
    goto MENU
)

for /f %%I in ('powershell.exe -NoLogo -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss"') do set "MARCA_TIEMPO=%%I"
set "RESUMEN_MASIVO=%CARPETA_REPORTES%\Resumen_Masivo_%MARCA_TIEMPO%.csv"
set /a TOTAL_MASIVO=0
set /a EXITOS_MASIVO=0
set /a FALLOS_MASIVO=0

>"%RESUMEN_MASIVO%" echo Equipo;Resultado;Codigo;ReporteHTML

echo Lista   : %LISTA_EQUIPOS%
echo Resumen : %RESUMEN_MASIVO%
echo.
echo Las lineas vacias y las iniciadas con # se ignoraran.
echo.

for /f "usebackq eol=# tokens=*" %%E in ("%LISTA_EQUIPOS%") do call :PROCESAR_MASIVO "%%E"

echo.
echo ============================================================
echo  RESUMEN DEL DESPLIEGUE MASIVO
echo ============================================================
echo Total procesados : %TOTAL_MASIVO%
echo Exitos           : %EXITOS_MASIVO%
echo Fallos           : %FALLOS_MASIVO%
echo.
echo Resumen CSV:
echo %RESUMEN_MASIVO%
echo ============================================================
echo.
if exist "%RESUMEN_MASIVO%" start "" "%RESUMEN_MASIVO%"
pause
goto MENU

:FIN
echo.
echo ============================================================
echo Reporte guardado en:
echo.
echo TXT : %REPORTE%
if defined REPORTE_HTML echo HTML: %REPORTE_HTML%
echo ============================================================
echo.
if defined REPORTE_HTML if exist "%REPORTE_HTML%" start "" "%REPORTE_HTML%"
pause
endlocal
exit /b 0

:PROCESAR_MASIVO
set "PC=%~1"
if not defined PC exit /b 0

set /a TOTAL_MASIVO+=1
echo.
echo ############################################################
echo  EQUIPO %TOTAL_MASIVO%: %PC%
echo ############################################################

call :VALIDAR_REMOTO "%PC%"
set "CODIGO_EQUIPO=%ERRORLEVEL%"

if "%CODIGO_EQUIPO%"=="0" (
    set /a EXITOS_MASIVO+=1
) else (
    set /a FALLOS_MASIVO+=1
)

>>"%RESUMEN_MASIVO%" echo "%PC%";"%ESTADO_EQUIPO%";"%CODIGO_EQUIPO%";"%REPORTE_HTML%"
exit /b 0

:VALIDAR_REMOTO
set "PC=%~1"
set "ESTADO_EQUIPO=INICIANDO"
set "REPORTE=%CARPETA_REPORTES%\%PC%_Checker.txt"
set "REPORTE_HTML=%CARPETA_REPORTES%\%PC%_Checker.html"

echo.
echo Equipo: %PC%
echo.

if not exist "%PSEXEC%" (
    echo ERROR: No se encontro PsExec:
    echo %PSEXEC%
    set "ESTADO_EQUIPO=PSEXEC_NO_ENCONTRADO"
    exit /b 2
)

echo [1/6] Validando conectividad SMB...
ping -n 1 -w 1500 "%PC%" >nul
if errorlevel 1 echo ADVERTENCIA: El equipo no responde al ping; se validara el puerto SMB.

set "CHECKER_PC=%PC%"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "if (Test-NetConnection -ComputerName $env:CHECKER_PC -Port 445 -InformationLevel Quiet -WarningAction SilentlyContinue) { exit 0 } else { exit 1 }" >nul 2>&1
if errorlevel 1 (
    echo ERROR: No fue posible conectar con %PC% por el puerto TCP 445.
    echo Valide DNS, encendido del equipo, VPN o firewall de SMB.
    set "ESTADO_EQUIPO=SIN_CONECTIVIDAD_SMB"
    exit /b 4
)
echo OK

echo [2/6] Validando acceso administrativo...
dir "\\%PC%\ADMIN$" >nul 2>&1
if errorlevel 1 (
    echo ERROR: No fue posible acceder a \\%PC%\ADMIN$.
    echo PsExec requiere permisos administrativos sobre ADMIN$.
    set "ESTADO_EQUIPO=SIN_ACCESO_ADMINISTRATIVO"
    exit /b 5
)
echo OK

echo [3/6] Copiando checker...
copy /Y "%SCRIPT%" "\\%PC%\ADMIN$\Temp\Checker-PC.ps1" >nul
if errorlevel 1 (
    echo ERROR: No fue posible copiar Checker-PC.ps1.
    set "ESTADO_EQUIPO=ERROR_COPIANDO_CHECKER"
    exit /b 6
)
echo OK

echo [4/6] Ejecutando checker remoto...
echo.

set "CHECKER_PSEXEC=%PSEXEC%"
set "CHECKER_TARGET=\\%PC%"
set "CHECKER_REPORT=%REPORTE%"

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "& $env:CHECKER_PSEXEC $env:CHECKER_TARGET '-accepteula' '-nobanner' '-s' 'powershell.exe' '-NoLogo' '-NoProfile' '-ExecutionPolicy' 'Bypass' '-File' 'C:\Windows\Temp\Checker-PC.ps1' '-RutaReporteHtml' 'C:\Windows\Temp\Checker-PC.html' 2>&1 | ForEach-Object { $_.ToString() } | Tee-Object -FilePath $env:CHECKER_REPORT; $codigo = $LASTEXITCODE; exit $codigo"
set "RESULTADO_PSEXEC=%ERRORLEVEL%"

echo.
echo [5/6] Recuperando reporte HTML...
set "HTML_RECUPERADO=0"
copy /Y "\\%PC%\ADMIN$\Temp\Checker-PC.html" "%REPORTE_HTML%" >nul
if errorlevel 1 (
    echo ADVERTENCIA: No fue posible copiar el reporte HTML remoto.
) else (
    set "HTML_RECUPERADO=1"
    echo OK
)

echo.
echo [6/6] Limpiando archivos temporales...
del "\\%PC%\ADMIN$\Temp\Checker-PC.ps1" >nul 2>&1
del "\\%PC%\ADMIN$\Temp\Checker-PC.html" >nul 2>&1
if exist "\\%PC%\ADMIN$\Temp\Checker-PC.ps1" (
    echo ADVERTENCIA: No fue posible eliminar el archivo temporal.
) else (
    echo OK
)

if not "%RESULTADO_PSEXEC%"=="0" (
    echo ERROR: PsExec termino con el codigo %RESULTADO_PSEXEC%.
    set "ESTADO_EQUIPO=ERROR_PSEXEC_%RESULTADO_PSEXEC%"
    exit /b 8
)

if not "%HTML_RECUPERADO%"=="1" (
    set "ESTADO_EQUIPO=HTML_NO_RECUPERADO"
    exit /b 7
)

set "ESTADO_EQUIPO=OK"
exit /b 0
