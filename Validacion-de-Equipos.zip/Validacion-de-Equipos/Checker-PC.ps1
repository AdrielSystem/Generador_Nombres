#requires -version 5.1

param(

    [string]$RutaReporteHtml = ""
)

$ErrorActionPreference = "SilentlyContinue"

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

# ============================================================
# CHECKER DE CERTIFICACION N1
# COLTEFINANCIERA
# ============================================================
#
# Estados posibles:
#
# SI       = Cumple
# NO       = No cumple
# REVISAR  = Se obtuvo evidencia, pero requiere política
#            corporativa o validación adicional.
#
# ============================================================

$VersionChecker = "19.1"


# ============================================================
# CONFIGURACION CORPORATIVA
# ============================================================

# DLP:
# CAMBIAR cuando sepamos el nombre EXACTO del agente corporativo.

$PatronDLP = @(
    "Safetica",
    "Forcepoint",
    "Symantec DLP",
    "Trellix DLP",
    "McAfee DLP",
    "Endpoint Protector",
    "Digital Guardian"
) -join "|"


# VPN corporativa

$PatronVPN = @(
    "FortiClient VPN",
    "FortiClient"
) -join "|"


# Grupo administradores:
#
# Solo se permiten los grupos indicados.
#
# Si el administrador local también debe permanecer
# en Administradores, cambiar $false por $true.

$PermitirAdministradorLocalEnAdministradores = $true


$AdministradoresPermitidos = @(

    "(?i)(^|\\)Help\s*Desk$",

    "(?i)(^|\\)Domain Admins$"

)


# JAVA requerido por COBIS.
#
# La validacion principal se realiza ejecutando java -version.
# El inventario de software se conserva como evidencia secundaria.

$VersionJavaAprobada = "1.8.0_411"
$PatronDistribucionJavaAprobada = "Java\(TM\) SE Runtime Environment"
$PatronArquitecturaJavaAprobada = "64-Bit"


# Componentes locales de COBIS Device Server.

$VersionCobisAprobada = "7.7.4"


# Windows:
#
# Antiguedad maxima permitida para el ultimo KB instalado.

$DiasMaximosWindowsUpdate = 45


# OU esperada de Active Directory.
#
# Ejemplo:
#
# "OU=Equipos,OU=Coltefinanciera"
#
# Vacío = solamente mostrar ubicación.

$OUEsperadaRegex = ""


# ============================================================
# RESULTADOS
# ============================================================

$Resultados = New-Object System.Collections.Generic.List[object]
$TotalControles = 32


function Mostrar-Avance {

    param(

        [int]$Numero,

        [string]$Control
    )

    $Porcentaje = [Math]::Floor(
        (($Numero - 1) / $TotalControles) * 100
    )

    Write-Host (
        "[{0}/{1}] {2}% - Validando: {3}" -f
        $Numero,
        $TotalControles,
        $Porcentaje,
        $Control
    ) -ForegroundColor Cyan
}


function Agregar-Resultado {

    param(

        [int]$Numero,

        [string]$Control,

        [string]$Estado,

        [string]$Detalle
    )

    $Resultados.Add(

        [PSCustomObject]@{

            Numero  = $Numero
            Control = $Control
            Estado  = $Estado
            Detalle = $Detalle

        }
    )
}


# ============================================================
# SOFTWARE INSTALADO
# ============================================================

Write-Host "[INICIO] Cargando inventario de software..." -ForegroundColor Cyan

$RutasSoftware = @(

    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*",

    "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*",

    "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*"

)


$script:SoftwareInstalado = @(

    Get-ItemProperty -Path $RutasSoftware -ErrorAction SilentlyContinue |
    Where-Object {

        $_.DisplayName

    } |
    Select-Object `
        DisplayName,
        DisplayVersion,
        Publisher |
    Sort-Object DisplayName, DisplayVersion -Unique

)

Write-Host (
    "[INICIO] Checker: {0}" -f $PSCommandPath
) -ForegroundColor DarkGray

Write-Host (
    "[INICIO] Version checker: {0}" -f $VersionChecker
) -ForegroundColor DarkGray

Write-Host (
    "[INICIO] PowerShell {0} | Proceso de {1} bits" -f
    $PSVersionTable.PSVersion,
    $(if ([Environment]::Is64BitProcess) { 64 } else { 32 })
) -ForegroundColor DarkGray

Write-Host (
    "[INICIO] Programas cargados en inventario: {0}" -f
    $script:SoftwareInstalado.Count
) -ForegroundColor Yellow


function Buscar-Software {

    param(

        [string]$Patron
    )

    $Coincidencias = @(

        $script:SoftwareInstalado |
        Where-Object {

            $_.DisplayName -match $Patron

        }
    )

    # La coma evita que PowerShell convierta una coincidencia unica
    # en un objeto escalar sin comportamiento uniforme de coleccion.
    return ,$Coincidencias
}


# ============================================================
# INFORMACION DEL EQUIPO
# ============================================================

Write-Host "[INICIO] Consultando sistema, fabricante y serial..." -ForegroundColor Cyan

$OS = Get-CimInstance Win32_OperatingSystem
$CS = Get-CimInstance Win32_ComputerSystem
$BIOS = Get-CimInstance Win32_BIOS


$Hostname = $env:COMPUTERNAME

$UsuarioActual = [string]$CS.UserName


# Cuando el checker se ejecuta remotamente con PsExec -s, algunos equipos
# reportan la cuenta de maquina (DOMINIO\EQUIPO$) como si fuera el usuario.
# Esa identidad no representa una sesion interactiva, por lo que se descarta
# antes de buscar al propietario de explorer.exe.
if (
    [string]::IsNullOrWhiteSpace($UsuarioActual) -or
    $UsuarioActual -match '\\[^\\]+\$$' -or
    $UsuarioActual -match '(?i)\\(SYSTEM|LOCAL SERVICE|NETWORK SERVICE)$'
) {

    $UsuariosExplorer = @(

        Get-CimInstance `
            Win32_Process `
            -Filter "Name='explorer.exe'" `
            -ErrorAction SilentlyContinue |
        ForEach-Object {

            $PropietarioExplorer = Invoke-CimMethod `
                -InputObject $_ `
                -MethodName GetOwner `
                -ErrorAction SilentlyContinue


            if (
                $PropietarioExplorer.ReturnValue -eq 0 -and
                $PropietarioExplorer.User
            ) {

                if ($PropietarioExplorer.Domain) {

                    "{0}\{1}" -f `
                        $PropietarioExplorer.Domain,
                        $PropietarioExplorer.User

                }
                else {

                    $PropietarioExplorer.User
                }
            }
        } |
        Sort-Object -Unique
    )


    if ($UsuariosExplorer.Count -gt 0) {

        $UsuarioActual = $UsuariosExplorer -join ", "

    }
    elseif (
        $env:USERNAME -and
        $env:USERNAME -notmatch "^(SYSTEM|LOCAL SERVICE|NETWORK SERVICE)$"
    ) {

        if ($env:USERDOMAIN) {

            $UsuarioActual = (
                "{0}\{1}" -f
                $env:USERDOMAIN,
                $env:USERNAME
            )

        }
        else {

            $UsuarioActual = $env:USERNAME
        }

    }
    else {

        $UsuarioActual = "Sin sesion interactiva"
    }
}

$FechaActual = Get-Date


# ============================================================
# 1 - ANTIVIRUS
# ============================================================

Mostrar-Avance 1 "Antivirus"

$Antivirus = @()

try {

    $Antivirus = @(

        Get-CimInstance `
        -Namespace root/SecurityCenter2 `
        -ClassName AntivirusProduct

    )

}
catch {}


if ($Antivirus.Count -gt 0) {

    $NombresAV = (

        $Antivirus |
        Select-Object -ExpandProperty displayName

    ) -join ", "

    Agregar-Resultado `
        1 `
        "Antivirus" `
        "SI" `
        $NombresAV

}
else {

    Agregar-Resultado `
        1 `
        "Antivirus" `
        "NO" `
        "Windows Security Center no reporta antivirus."

}


# ============================================================
# 2 - DLP
# ============================================================

Mostrar-Avance 2 "DLP"

$DLP = Buscar-Software $PatronDLP
$Safetica = Buscar-Software "^Safetica$|^Safetica Agent$"

$ServicioSafetica = Get-CimInstance Win32_Service `
    -Filter "Name='STCService'" `
    -ErrorAction SilentlyContinue

$ServiciosAuxiliaresSafetica = @(

    Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
    Where-Object {

        $_.Name -in @(
            "ContentService",
            "STEndpointServer",
            "STInfoService"
        )
    }
)


if ($Safetica.Count -gt 0) {

    $DetalleSafetica = @(

        $Safetica |
        ForEach-Object {

            "$($_.DisplayName) $($_.DisplayVersion)"
        }

    ) -join ", "

    $AuxiliaresActivos = @(

        $ServiciosAuxiliaresSafetica |
        Where-Object {

            $_.State -eq "Running"
        }

    ).Count

    if (
        $ServicioSafetica -and
        $ServicioSafetica.State -eq "Running" -and
        $ServicioSafetica.StartMode -eq "Auto"
    ) {

        Agregar-Resultado `
            2 `
            "DLP" `
            "SI" `
            (
                "$DetalleSafetica | " +
                "STCService: Running/Auto | " +
                "Servicios auxiliares activos: " +
                "$AuxiliaresActivos/3"
            )

    }
    else {

        $EstadoServicio = if ($ServicioSafetica) {

            "$($ServicioSafetica.State)/$($ServicioSafetica.StartMode)"

        }
        else {

            "No encontrado"
        }

        Agregar-Resultado `
            2 `
            "DLP" `
            "REVISAR" `
            (
                "$DetalleSafetica | " +
                "STCService: $EstadoServicio"
            )
    }

}
elseif ($DLP.Count -gt 0) {

    Agregar-Resultado `
        2 `
        "DLP" `
        "REVISAR" `
        (
            "Otro DLP detectado: " +
            (($DLP.DisplayName + " " + $DLP.DisplayVersion) -join ", ")
        )

}
else {

    Agregar-Resultado `
        2 `
        "DLP" `
        "NO" `
        "No se detecto DLP usando el patron configurado."

}


# ============================================================
# 3 - CIFRADO DISCO
# ============================================================

Mostrar-Avance 3 "Cifrado del disco"

try {

    $UnidadSistema = $env:SystemDrive

    $BitLocker = Get-BitLockerVolume `
        -MountPoint $UnidadSistema


    if (
        $BitLocker.ProtectionStatus -eq "On" -and
        $BitLocker.VolumeStatus -match "FullyEncrypted"
    ) {

        Agregar-Resultado `
            3 `
            "Cifrado del Disco Duro" `
            "SI" `
            "$UnidadSistema BitLocker activo y cifrado."

    }
    else {

        Agregar-Resultado `
            3 `
            "Cifrado del Disco Duro" `
            "NO" `
            "Estado: $($BitLocker.VolumeStatus) / Proteccion: $($BitLocker.ProtectionStatus)"

    }

}
catch {

    Agregar-Resultado `
        3 `
        "Cifrado del Disco Duro" `
        "REVISAR" `
        "No fue posible consultar BitLocker."

}


# ============================================================
# FUNCIONES GRUPOS LOCALES POR SID
# ============================================================

function Obtener-NombreGrupoSID {

    param(

        [string]$SID
    )

    try {

        $SidObject = New-Object `
            System.Security.Principal.SecurityIdentifier($SID)

        $Cuenta = $SidObject.Translate(
            [System.Security.Principal.NTAccount]
        )

        return ($Cuenta.Value -split "\\")[-1]

    }
    catch {

        return $null
    }
}


# ============================================================
# ADMINISTRADOR LOCAL SID 500
# ============================================================

$AdministradorLocal = @(

    Get-LocalUser |
    Where-Object {

        $_.SID.Value -match "-500$"

    }

) | Select-Object -First 1


# ============================================================
# 4 - GRUPO ADMINISTRADORES
# ============================================================

Mostrar-Avance 4 "Grupo Administradores"

$GrupoAdministradores = Obtener-NombreGrupoSID `
    "S-1-5-32-544"


$MiembrosAdmin = @(

    Get-LocalGroupMember `
        -Group $GrupoAdministradores

)


$MiembrosNoPermitidos = @()


foreach ($Miembro in $MiembrosAdmin) {

    $Permitido = $false

    foreach ($Patron in $AdministradoresPermitidos) {

        if ($Miembro.Name -match $Patron) {

            $Permitido = $true
        }
    }


    if (
        $PermitirAdministradorLocalEnAdministradores -and
        $AdministradorLocal
    ) {

        if (
            $Miembro.SID.Value -eq
            $AdministradorLocal.SID.Value
        ) {

            $Permitido = $true
        }
    }


    if (-not $Permitido) {

        $MiembrosNoPermitidos += $Miembro.Name
    }
}


if ($MiembrosNoPermitidos.Count -eq 0) {

    Agregar-Resultado `
        4 `
        "Grupo Administradores" `
        "SI" `
        (($MiembrosAdmin.Name) -join ", ")

}
else {

    Agregar-Resultado `
        4 `
        "Grupo Administradores" `
        "NO" `
        ("No permitidos: " + ($MiembrosNoPermitidos -join ", "))

}


# ============================================================
# 5 - USUARIOS AVANZADOS
# ============================================================

Mostrar-Avance 5 "Usuarios avanzados"

$GrupoPowerUsers = Obtener-NombreGrupoSID `
    "S-1-5-32-547"


$PowerUsers = @(

    Get-LocalGroupMember `
        -Group $GrupoPowerUsers

)


if ($PowerUsers.Count -eq 0) {

    Agregar-Resultado `
        5 `
        "Grupo Usuarios Avanzados" `
        "SI" `
        "Grupo vacio."

}
else {

    Agregar-Resultado `
        5 `
        "Grupo Usuarios Avanzados" `
        "NO" `
        (($PowerUsers.Name) -join ", ")

}


# ============================================================
# 6 - USUARIOS LOCALES
# ============================================================

Mostrar-Avance 6 "Usuarios locales"

$UsuariosLocalesActivos = @(

    Get-LocalUser |
    Where-Object {

        $_.Enabled

    }

)


$UsuariosLocalesNoPermitidos = @(

    $UsuariosLocalesActivos |
    Where-Object {

        $_.SID.Value -notmatch "-500$"

    }

)


if ($UsuariosLocalesNoPermitidos.Count -eq 0) {

    Agregar-Resultado `
        6 `
        "Usuarios locales" `
        "SI" `
        "Solo administrador local habilitado."

}
else {

    Agregar-Resultado `
        6 `
        "Usuarios locales" `
        "NO" `
        (
            "Usuarios adicionales habilitados: " +
            ($UsuariosLocalesNoPermitidos.Name -join ", ")
        )

}


# ============================================================
# 7 - CLAVES DE ADMINISTRADORES LOCALES
# ============================================================

Mostrar-Avance 7 "Claves de administradores locales"

$AdministradoresLocalesHabilitados = @(

    foreach ($Miembro in $MiembrosAdmin) {

        if ($Miembro.PrincipalSource -eq "Local") {

            $UsuarioLocalAdmin = Get-LocalUser `
                -SID $Miembro.SID `
                -ErrorAction SilentlyContinue

            if (
                $UsuarioLocalAdmin -and
                $UsuarioLocalAdmin.Enabled
            ) {

                $UsuarioLocalAdmin
            }
        }
    }
)

$AdministradoresLocalesSinClaveSegura = @(

    $AdministradoresLocalesHabilitados |
    Where-Object {

        -not $_.PasswordRequired -or
        -not $_.PasswordLastSet
    }
)

$DetalleAdministradoresLocales = @(

    $AdministradoresLocalesHabilitados |
    ForEach-Object {

        (
            "$($_.Name): " +
            "PasswordRequired=$($_.PasswordRequired), " +
            "UltimoCambio=$($_.PasswordLastSet)"
        )
    }

) -join " | "


if ($AdministradoresLocalesHabilitados.Count -eq 0) {

    Agregar-Resultado `
        7 `
        "Claves Administradores Locales" `
        "SI" `
        "No existen cuentas administrativas locales habilitadas."

}
elseif ($AdministradoresLocalesSinClaveSegura.Count -eq 0) {

    Agregar-Resultado `
        7 `
        "Claves Administradores Locales" `
        "SI" `
        $DetalleAdministradoresLocales

}
else {

    Agregar-Resultado `
        7 `
        "Claves Administradores Locales" `
        "NO" `
        (
            "Cuentas sin requisito de clave o sin fecha de cambio: " +
            ($AdministradoresLocalesSinClaveSegura.Name -join ", ") +
            " | Detalle: $DetalleAdministradoresLocales"
        )
}


# ============================================================
# 8 - WINDOWS / SERVICE PACK / BUILD
# ============================================================

Mostrar-Avance 8 "Windows, build y actualizaciones"

$UltimoKB = @(

    Get-HotFix |
    Where-Object {

        $_.InstalledOn
    } |
    Sort-Object InstalledOn -Descending

) | Select-Object -First 1

$RegistroWindows = Get-ItemProperty `
    "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion" `
    -ErrorAction SilentlyContinue

$BuildCompletoWindows = "$($OS.BuildNumber)"

if ($RegistroWindows.UBR -ne $null) {

    $BuildCompletoWindows += ".$($RegistroWindows.UBR)"
}

$ReinicioCBS = Test-Path `
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending"

$ReinicioWindowsUpdate = Test-Path `
    "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired"

$PendientesArchivos = @(

    (
        Get-ItemProperty `
            "HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager" `
            -Name PendingFileRenameOperations `
            -ErrorAction SilentlyContinue
    ).PendingFileRenameOperations
)

$OperacionesAplicacionesPendientes = [Math]::Ceiling(
    $PendientesArchivos.Count / 2
)

$DiasDesdeUltimoKB = $null

if ($UltimoKB -and $UltimoKB.InstalledOn) {

    $DiasDesdeUltimoKB = [Math]::Floor(
        ((Get-Date) - [DateTime]$UltimoKB.InstalledOn).TotalDays
    )
}


$DetalleWindows = (

    "$($OS.Caption) | " +
    "Version $($OS.Version) | " +
    "Build $BuildCompletoWindows"
)


if ($UltimoKB) {

    $DetalleWindows += (
        " | Ultimo KB: " +
        "$($UltimoKB.HotFixID) " +
        "$($UltimoKB.InstalledOn) | " +
        "Antiguedad: $DiasDesdeUltimoKB dias"
    )
}

$DetalleWindows += (
    " | Reinicio Windows: CBS=$ReinicioCBS/" +
    "WU=$ReinicioWindowsUpdate"
)

if ($OperacionesAplicacionesPendientes -gt 0) {

    $DetalleWindows += (
        " | Advertencia: " +
        "$OperacionesAplicacionesPendientes operaciones de " +
        "aplicaciones pendientes de reinicio"
    )
}


if (-not $UltimoKB -or $DiasDesdeUltimoKB -eq $null) {

    $EstadoWindows = "REVISAR"

}
elseif (
    $ReinicioCBS -or
    $ReinicioWindowsUpdate
) {

    $EstadoWindows = "REVISAR"

}
elseif ($DiasDesdeUltimoKB -le $DiasMaximosWindowsUpdate) {

    $EstadoWindows = "SI"

}
else {

    $EstadoWindows = "NO"
}


Agregar-Resultado `
    8 `
    "Service Pack / Windows actualizado" `
    $EstadoWindows `
    $DetalleWindows


# ============================================================
# 9 - FIREWALL
# ============================================================

Mostrar-Avance 9 "Firewall"

$Firewall = @(

    Get-NetFirewallProfile

)


$FirewallDeshabilitado = @(

    $Firewall |
    Where-Object {

        -not $_.Enabled

    }

)


if ($FirewallDeshabilitado.Count -eq 0) {

    Agregar-Resultado `
        9 `
        "Firewall Habilitado" `
        "SI" `
        "Domain, Private y Public habilitados."

}
else {

    Agregar-Resultado `
        9 `
        "Firewall Habilitado" `
        "NO" `
        (
            "Deshabilitados: " +
            ($FirewallDeshabilitado.Name -join ", ")
        )

}


# ============================================================
# 10 - CARPETAS COMPARTIDAS
# ============================================================

Mostrar-Avance 10 "Carpetas compartidas"

$Compartidos = @(

    Get-SmbShare |
    Where-Object {

        $_.Name -ne "IPC$" -and
        $_.Name -notmatch "\$$" -and
        -not $_.Special

    }

)


if ($Compartidos.Count -eq 0) {

    Agregar-Resultado `
        10 `
        "Carpetas compartidas" `
        "SI" `
        "No existen recursos compartidos adicionales."

}
else {

    Agregar-Resultado `
        10 `
        "Carpetas compartidas" `
        "NO" `
        (($Compartidos.Name) -join ", ")

}


# ============================================================
# 11 - OFFICE LICENCIADO
# ============================================================

Mostrar-Avance 11 "Office y licencia"

$OfficeInstalado = Buscar-Software `
    "Microsoft 365|Microsoft Office"

$VNextDiag = @(

    Get-ChildItem `
        "C:\Program Files\Microsoft Office",
        "C:\Program Files (x86)\Microsoft Office" `
        -Filter "vnextdiag.ps1" `
        -Recurse `
        -ErrorAction SilentlyContinue

) | Select-Object -First 1

$TextoVNext = ""
$LicenciaVNextActiva = $false
$ProductoVNext = ""
$VigenciaVNext = ""

if ($VNextDiag) {

    $SalidaVNext = @(

        powershell.exe `
            -NoLogo `
            -NoProfile `
            -ExecutionPolicy Bypass `
            -File $VNextDiag.FullName `
            -action list 2>&1
    )

    $TextoVNext = $SalidaVNext -join [Environment]::NewLine

    $LicenciaVNextActiva = (
        $TextoVNext -match
        '(?i)"LicenseState"\s*:\s*"Licensed"'
    )

    $CoincidenciaProducto = [regex]::Match(
        $TextoVNext,
        '(?i)"Product"\s*:\s*"([^"]+)"'
    )

    if ($CoincidenciaProducto.Success) {

        $ProductoVNext = $CoincidenciaProducto.Groups[1].Value
    }

    $CoincidenciaVigencia = [regex]::Match(
        $TextoVNext,
        '(?i)"NotAfter"\s*:\s*"([^"]+)"'
    )

    if ($CoincidenciaVigencia.Success) {

        $VigenciaVNext = $CoincidenciaVigencia.Groups[1].Value
    }
}


$OfficeLicencia = @(

    Get-CimInstance SoftwareLicensingProduct -ErrorAction SilentlyContinue |
    Where-Object {

        $_.Name -match "Office" -and
        $_.LicenseStatus -eq 1

    }

)


if (
    $OfficeInstalado.Count -gt 0 -and
    $LicenciaVNextActiva
) {

    $DetalleLicenciaOffice = (
        "Microsoft 365 licenciado por vNextDiag"
    )

    if ($ProductoVNext) {

        $DetalleLicenciaOffice += " | Producto: $ProductoVNext"
    }

    if ($VigenciaVNext) {

        $DetalleLicenciaOffice += " | Vigencia: $VigenciaVNext"
    }

    Agregar-Resultado `
        11 `
        "Office licenciado y activado" `
        "SI" `
        $DetalleLicenciaOffice

}
elseif (
    $OfficeInstalado.Count -gt 0 -and
    $OfficeLicencia.Count -gt 0
) {

    Agregar-Resultado `
        11 `
        "Office licenciado y activado" `
        "SI" `
        "Office instalado y Windows Licensing reporta licencia activa."

}
elseif ($OfficeInstalado.Count -gt 0) {

    Agregar-Resultado `
        11 `
        "Office licenciado y activado" `
        "REVISAR" `
        "Office instalado; no fue posible confirmar activacion automaticamente."

}
else {

    Agregar-Resultado `
        11 `
        "Office licenciado y activado" `
        "NO" `
        "Office no detectado."

}


# ============================================================
# 12 - SESIONES NULAS
# ============================================================

Mostrar-Avance 12 "Bloqueo de acceso anonimo y sesiones nulas"

$PoliticaLSA = Get-ItemProperty `
    "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" `
    -ErrorAction SilentlyContinue

$PoliticaServidor = Get-ItemProperty `
    "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" `
    -ErrorAction SilentlyContinue

$RestrictAnonymous = $PoliticaLSA.RestrictAnonymous
$RestrictAnonymousSAM = $PoliticaLSA.RestrictAnonymousSAM
$EveryoneIncludesAnonymous = $PoliticaLSA.EveryoneIncludesAnonymous
$RestrictNull = $PoliticaServidor.RestrictNullSessAccess

$NullSessionPipes = @(

    $PoliticaServidor.NullSessionPipes |
    Where-Object {

        -not [string]::IsNullOrWhiteSpace([string]$_)
    }
)

$NullSessionShares = @(

    $PoliticaServidor.NullSessionShares |
    Where-Object {

        -not [string]::IsNullOrWhiteSpace([string]$_)
    }
)

$IncumplimientosSesionNula = @()

if ($RestrictAnonymous -ne 1) {
    $IncumplimientosSesionNula += "RestrictAnonymous=$RestrictAnonymous"
}

if ($RestrictAnonymousSAM -ne 1) {
    $IncumplimientosSesionNula += "RestrictAnonymousSAM=$RestrictAnonymousSAM"
}

if ($EveryoneIncludesAnonymous -ne 0) {
    $IncumplimientosSesionNula += (
        "EveryoneIncludesAnonymous=$EveryoneIncludesAnonymous"
    )
}

if ($RestrictNull -ne 1) {
    $IncumplimientosSesionNula += (
        "RestrictNullSessAccess=$RestrictNull"
    )
}

if ($NullSessionPipes.Count -gt 0) {
    $IncumplimientosSesionNula += (
        "NullSessionPipes=" + ($NullSessionPipes -join ",")
    )
}

if ($NullSessionShares.Count -gt 0) {
    $IncumplimientosSesionNula += (
        "NullSessionShares=" + ($NullSessionShares -join ",")
    )
}

$DetalleSesionesNulas = (
    "RestrictAnonymous=$RestrictAnonymous | " +
    "RestrictAnonymousSAM=$RestrictAnonymousSAM | " +
    "EveryoneIncludesAnonymous=$EveryoneIncludesAnonymous | " +
    "RestrictNullSessAccess=$RestrictNull | " +
    "NullSessionPipes=$($NullSessionPipes.Count) | " +
    "NullSessionShares=$($NullSessionShares.Count)"
)


if ($IncumplimientosSesionNula.Count -eq 0) {

    Agregar-Resultado `
        12 `
        "Bloqueo de acceso anonimo y sesiones nulas" `
        "SI" `
        $DetalleSesionesNulas

}
else {

    Agregar-Resultado `
        12 `
        "Bloqueo de acceso anonimo y sesiones nulas" `
        "NO" `
        (
            "Incumple: " +
            ($IncumplimientosSesionNula -join ", ") +
            " | Evidencia: $DetalleSesionesNulas"
        )

}


# ============================================================
# FUNCION SIMPLE SOFTWARE
# ============================================================

function Validar-Programa {

    param(

        [int]$Numero,

        [string]$Nombre,

        [string]$Patron
    )

    $Encontrado = Buscar-Software $Patron


    if ($Encontrado.Count -gt 0) {

        $Detalle = @(

            $Encontrado |
            ForEach-Object {

                "$($_.DisplayName) $($_.DisplayVersion)"

            }

        ) -join ", "


        Agregar-Resultado `
            $Numero `
            $Nombre `
            "SI" `
            $Detalle

    }
    else {

        Agregar-Resultado `
            $Numero `
            $Nombre `
            "NO" `
            "No instalado."

    }
}


# ============================================================
# 13 - ADOBE READER
# ============================================================

Mostrar-Avance 13 "Adobe Reader"

Validar-Programa `
    13 `
    "Adobe Reader" `
    "Adobe Acrobat|Adobe Reader"


# ============================================================
# 14 - ULTRAVNC
# ============================================================

Mostrar-Avance 14 "UltraVNC"

Validar-Programa `
    14 `
    "Ultra VNC" `
    "UltraVNC|Ultra VNC"


# ============================================================
# 15 - JAVA
# ============================================================

Mostrar-Avance 15 "Java JRE"

$JavaInventario = Buscar-Software `
    "Java|JRE|JDK|OpenJDK|Temurin|Adoptium|Zulu|Corretto"

$JavaCommand = Get-Command `
    "java.exe" `
    -CommandType Application `
    -ErrorAction SilentlyContinue |
    Select-Object -First 1

$RutaJavaEjecutable = ""


if ($JavaCommand) {

    $RutaJavaEjecutable = $JavaCommand.Source

}
else {

    $RutasBaseJava = @(

        "C:\Program Files\Java",
        "C:\Program Files (x86)\Java"
    )


    if ($env:JAVA_HOME) {

        $RutasBaseJava += $env:JAVA_HOME
    }

    $RutasBaseJava = @(

        $RutasBaseJava |
        Where-Object {

            Test-Path $_
        } |
        Select-Object -Unique
    )


    if ($RutasBaseJava.Count -gt 0) {

        $JavaArchivo = @(

            Get-ChildItem `
                -Path $RutasBaseJava `
                -Filter "java.exe" `
                -File `
                -Recurse `
                -ErrorAction SilentlyContinue |
            Where-Object {

                $_.DirectoryName -match "\\bin$"
            }
        ) |
        Select-Object -First 1


        if ($JavaArchivo) {

            $RutaJavaEjecutable = $JavaArchivo.FullName
        }
    }
}

$JavaEjecutableDetectado = $false
$JavaVersionDetectada = ""
$JavaDistribucionDetectada = "No identificada"
$JavaArquitecturaDetectada = "No identificada"
$SalidaJavaTexto = ""


if ($RutaJavaEjecutable) {

    try {

        $InicioProcesoJava = `
            New-Object System.Diagnostics.ProcessStartInfo

        $InicioProcesoJava.FileName = $RutaJavaEjecutable
        $InicioProcesoJava.Arguments = "-version"
        $InicioProcesoJava.UseShellExecute = $false
        $InicioProcesoJava.CreateNoWindow = $true
        $InicioProcesoJava.RedirectStandardOutput = $true
        $InicioProcesoJava.RedirectStandardError = $true

        $ProcesoJava = New-Object System.Diagnostics.Process
        $ProcesoJava.StartInfo = $InicioProcesoJava

        if ($ProcesoJava.Start()) {

            $SalidaJavaStdOut = `
                $ProcesoJava.StandardOutput.ReadToEnd()

            $SalidaJavaStdErr = `
                $ProcesoJava.StandardError.ReadToEnd()

            $ProcesoJava.WaitForExit()

            $SalidaJavaTexto = @(

                $SalidaJavaStdOut.Trim(),
                $SalidaJavaStdErr.Trim()

            ) |
            Where-Object {

                $_

            }

            $SalidaJavaTexto = (
                $SalidaJavaTexto -join " | "
            ) -replace "[\r\n]+", " | "

            $SalidaJavaTexto = $SalidaJavaTexto.Trim()
        }

        $ProcesoJava.Dispose()

    }
    catch {

        $SalidaJavaTexto = (
            "Error al ejecutar java.exe: {0}" -f
            $_.Exception.Message
        )
    }

    $CoincidenciaVersionJava = [regex]::Match(
        $SalidaJavaTexto,
        '(?:java|openjdk) version "(?<Version>[^"]+)"'
    )


    if ($CoincidenciaVersionJava.Success) {

        $JavaEjecutableDetectado = $true
        $JavaVersionDetectada = `
            $CoincidenciaVersionJava.Groups["Version"].Value
    }


    if (
        $SalidaJavaTexto -match
        "Java\(TM\) SE Runtime Environment"
    ) {

        $JavaDistribucionDetectada = `
            "Oracle Java(TM) SE Runtime Environment"

    }
    elseif ($SalidaJavaTexto -match "OpenJDK") {

        $JavaDistribucionDetectada = "OpenJDK"
    }


    if ($SalidaJavaTexto -match "64-Bit") {

        $JavaArquitecturaDetectada = "64 bits"

    }
    elseif ($SalidaJavaTexto -match "32-Bit|Client VM") {

        $JavaArquitecturaDetectada = "32 bits"
    }
}


if (-not $JavaEjecutableDetectado) {

    if ($JavaInventario.Count -gt 0) {

        $DetalleJavaInventario = (

            $JavaInventario |
            ForEach-Object {

                "$($_.DisplayName) $($_.DisplayVersion)"
            }

        ) -join ", "

        $DetalleJava = (
            "Detectado en inventario: {0}; " +
            "pero java -version no esta disponible."
        ) -f $DetalleJavaInventario

    }
    else {

        $DetalleJava = (
            "Java no detectado: java -version no esta disponible " +
            "y no aparece en el inventario."
        )
    }


    Agregar-Resultado `
        15 `
        "JRE de JAVA" `
        "NO" `
        $DetalleJava

}
else {

    $VersionJavaCumple = (
        $JavaVersionDetectada -eq $VersionJavaAprobada
    )

    $DistribucionJavaCumple = (
        $SalidaJavaTexto -match
        $PatronDistribucionJavaAprobada
    )

    $ArquitecturaJavaCumple = (
        $SalidaJavaTexto -match
        $PatronArquitecturaJavaAprobada
    )


    if (
        $VersionJavaCumple -and
        $DistribucionJavaCumple -and
        $ArquitecturaJavaCumple
    ) {

        $EstadoJava = "SI"

    }
    else {

        $EstadoJava = "NO"
    }


    $DetalleJava = (
        "java -version: {0} | Distribucion: {1} | " +
        "Arquitectura: {2} | Ruta: {3} | " +
        "Requerido: Oracle Java 1.8.0_411 de 64 bits"
    ) -f `
        $JavaVersionDetectada,
        $JavaDistribucionDetectada,
        $JavaArquitecturaDetectada,
        $RutaJavaEjecutable


    Agregar-Resultado `
        15 `
        "JRE de JAVA" `
        $EstadoJava `
        $DetalleJava
}


# ============================================================
# 16 - 7ZIP
# ============================================================

Mostrar-Avance 16 "7-Zip"

Validar-Programa `
    16 `
    "7-ZIP" `
    "^7-Zip"


# ============================================================
# 17 - PDF CREATOR
# ============================================================

Mostrar-Avance 17 "PDFCreator"

Validar-Programa `
    17 `
    "PDF Creator" `
    "PDFCreator|PDF Creator"


# ============================================================
# 18 - TPM 2.0 Y SECURE BOOT
# ============================================================

Mostrar-Avance 18 "TPM 2.0 y Secure Boot"

$TpmEstado = $null
$TpmCim = $null
$ErrorTpm = ""
$SecureBootHabilitado = $null
$ErrorSecureBoot = ""


try {

    $TpmEstado = Get-Tpm -ErrorAction Stop

    $TpmCim = Get-CimInstance `
        -Namespace "root\CIMV2\Security\MicrosoftTpm" `
        -ClassName Win32_Tpm `
        -ErrorAction Stop

}
catch {

    $ErrorTpm = $_.Exception.Message
}


try {

    $SecureBootHabilitado = `
        Confirm-SecureBootUEFI -ErrorAction Stop

}
catch {

    $ErrorSecureBoot = $_.Exception.Message
}

$VersionEsTPM20 = $false
$VersionTPM = "No detectada"
$FabricanteTPM = "No detectado"


if ($TpmCim) {

    $VersionTPM = [string]$TpmCim.SpecVersion

    if ($TpmEstado.ManufacturerIdTxt) {

        $FabricanteTPM = `
            [string]$TpmEstado.ManufacturerIdTxt

    }
    else {

        $FabricanteTPM = `
            [string]$TpmCim.ManufacturerId
    }

    $VersionEsTPM20 = (
        $VersionTPM -match
        '(^|[,\s])2\.0($|[,\s])'
    )
}

$TpmCumple = (
    $TpmEstado -and
    $TpmEstado.TpmPresent -eq $true -and
    $TpmEstado.TpmReady -eq $true -and
    $TpmEstado.TpmEnabled -eq $true -and
    $TpmEstado.TpmActivated -eq $true -and
    $VersionEsTPM20 -and
    $SecureBootHabilitado -eq $true
)


if ($TpmEstado) {

    $DetalleTPM = (
        "TPM presente={0}, listo={1}, habilitado={2}, " +
        "activado={3}, propiedad={4} | SpecVersion={5} | " +
        "Fabricante={6} | SecureBoot={7}"
    ) -f `
        $TpmEstado.TpmPresent,
        $TpmEstado.TpmReady,
        $TpmEstado.TpmEnabled,
        $TpmEstado.TpmActivated,
        $TpmEstado.TpmOwned,
        $VersionTPM,
        $FabricanteTPM,
        $(
            if ($null -eq $SecureBootHabilitado) {

                "No verificable"

            }
            else {

                $SecureBootHabilitado
            }
        )

}
else {

    $DetalleTPM = "No fue posible consultar el TPM."
}


if ($ErrorTpm) {

    $DetalleTPM += " | Error TPM: $ErrorTpm"
}


if ($ErrorSecureBoot) {

    $DetalleTPM += (
        " | Error Secure Boot: $ErrorSecureBoot"
    )
}


Agregar-Resultado `
    18 `
    "TPM 2.0 y Secure Boot" `
    $(if ($TpmCumple) { "SI" } else { "NO" }) `
    $DetalleTPM


# ============================================================
# 19 - NETBIOS
# ============================================================

Mostrar-Avance 19 "NetBIOS"

$AdaptadoresIP = @(

    Get-CimInstance `
        Win32_NetworkAdapterConfiguration |
    Where-Object {

        $_.IPEnabled

    }

)


$NetBiosHabilitado = @(

    $AdaptadoresIP |
    Where-Object {

        $_.TcpipNetbiosOptions -ne 2

    }

)

$DetalleNetBiosIncorrecto = @(

    $NetBiosHabilitado |
    ForEach-Object {

        $InterpretacionNetBios = switch ($_.TcpipNetbiosOptions) {
            0 { "Configurado por DHCP" }
            1 { "NetBIOS habilitado" }
            2 { "NetBIOS deshabilitado" }
            default { "Valor desconocido" }
        }

        (
            "$($_.Description): " +
            "Valor=$($_.TcpipNetbiosOptions) " +
            "($InterpretacionNetBios), " +
            "DHCP=$($_.DHCPEnabled)"
        )
    }

) -join " | "

if ($AdaptadoresIP.Count -eq 0) {

    Agregar-Resultado `
        19 `
        "NetBIOS deshabilitado" `
        "REVISAR" `
        "No fue posible consultar adaptadores IP habilitados."

}
elseif ($NetBiosHabilitado.Count -eq 0) {

    Agregar-Resultado `
        19 `
        "NetBIOS deshabilitado" `
        "SI" `
        (
            "NetBIOS deshabilitado explicitamente en " +
            "$($AdaptadoresIP.Count) adaptador(es) IP."
        )

}
else {

    Agregar-Resultado `
        19 `
        "NetBIOS deshabilitado" `
        "NO" `
        (
            "Adaptadores sin deshabilitacion explicita: " +
            $DetalleNetBiosIncorrecto
        )

}


# ============================================================
# 20 - WAKE ON LAN
# ============================================================

Mostrar-Avance 20 "Wake on LAN"

$WolProperties = @()

try {

    $AdaptadoresFisicos = @(

        Get-NetAdapter `
            -Physical |
        Where-Object {

            $_.Status -ne "Disabled"

        }

    )


    foreach ($Adaptador in $AdaptadoresFisicos) {

        $WolProperties += @(

            Get-NetAdapterAdvancedProperty `
                -Name $Adaptador.Name |
            Where-Object {

                $_.DisplayName -match "Wake|Magic|PME|Despert" -or
                $_.RegistryKeyword -match "Wake|Magic|PME"

            }

        )
    }

}
catch {}


if ($WolProperties.Count -eq 0) {

    Agregar-Resultado `
        20 `
        "Wake on LAN" `
        "REVISAR" `
        "El controlador no expone una propiedad WOL reconocible."

}
else {

    $WolEnabled = @(

        $WolProperties |
        Where-Object {

            $_.DisplayValue -match `
            "Enabled|Activado|On|Magic Packet"

        }

    )


    if ($WolEnabled.Count -gt 0) {

        Agregar-Resultado `
            20 `
            "Wake on LAN" `
            "SI" `
            (
                ($WolEnabled.DisplayName) -join ", "
            )

    }
    else {

        Agregar-Resultado `
            20 `
            "Wake on LAN" `
            "NO" `
            (
                ($WolProperties.DisplayValue) -join ", "
            )

    }

}


# ============================================================
# 21 - JAVA AUTO UPDATE
# ============================================================

Mostrar-Avance 21 "Actualizacion automatica de Java"

$JavaUpdate = $null
$PoliticasJavaUpdate = @()


$RutasJavaUpdate = @(

    "HKLM:\SOFTWARE\JavaSoft\Java Update\Policy",

    "HKLM:\SOFTWARE\WOW6432Node\JavaSoft\Java Update\Policy"

)


foreach ($Ruta in $RutasJavaUpdate) {

    if (Test-Path $Ruta) {

        $ValorJavaUpdate = Get-ItemProperty $Ruta

        $ValorEnableJavaUpdate = `
            $ValorJavaUpdate.EnableJavaUpdate

        $PoliticasJavaUpdate += (
            "{0}: EnableJavaUpdate={1}" -f
            $Ruta,
            $(
                if ($null -eq $ValorEnableJavaUpdate) {

                    "No configurado"

                }
                else {

                    $ValorEnableJavaUpdate
                }
            )
        )


        if (
            $ValorEnableJavaUpdate -eq 0
        ) {

            $JavaUpdate = $false
        }
    }
}


if (-not $JavaEjecutableDetectado) {

    Agregar-Resultado `
        21 `
        "Actualizacion automatica Java deshabilitada" `
        "NO" `
        (
            "No se puede validar la actualizacion automatica: " +
            "Java no esta disponible mediante java -version."
        )

}
elseif ($JavaUpdate -eq $false) {

    Agregar-Resultado `
        21 `
        "Actualizacion automatica Java deshabilitada" `
        "SI" `
        ($PoliticasJavaUpdate -join " | ")

}
else {

    if ($PoliticasJavaUpdate.Count -gt 0) {

        $DetalleJavaUpdate = $PoliticasJavaUpdate -join " | "

    }
    else {

        $DetalleJavaUpdate = (
            "Java esta disponible, pero no se encontro la politica " +
            "EnableJavaUpdate=0."
        )
    }

    Agregar-Resultado `
        21 `
        "Actualizacion automatica Java deshabilitada" `
        "NO" `
        $DetalleJavaUpdate

}


# ============================================================
# 22 - ADOBE AUTO UPDATE
# ============================================================

Mostrar-Avance 22 "Actualizacion automatica de Adobe"

$AdobeUpdateDisabled = $false
$PoliticasAdobeEncontradas = @()


$RutasAdobe = @(

    "HKLM:\SOFTWARE\Policies\Adobe\Adobe Acrobat\DC\FeatureLockDown",

    "HKLM:\SOFTWARE\Policies\Adobe\Acrobat Reader\DC\FeatureLockDown",

    "HKLM:\SOFTWARE\WOW6432Node\Policies\Adobe\Adobe Acrobat\DC\FeatureLockDown",

    "HKLM:\SOFTWARE\WOW6432Node\Policies\Adobe\Acrobat Reader\DC\FeatureLockDown"

)


foreach ($Ruta in $RutasAdobe) {

    if (Test-Path $Ruta) {

        $AdobePolicy = Get-ItemProperty `
            $Ruta `
            -ErrorAction SilentlyContinue

        $TieneBUpdater = (
            $AdobePolicy.PSObject.Properties.Name -contains "bUpdater"
        )

        if ($TieneBUpdater) {

            $PoliticasAdobeEncontradas += (
                "$Ruta => bUpdater=$($AdobePolicy.bUpdater)"
            )
        }

        if ($AdobePolicy.bUpdater -eq 0) {

            $AdobeUpdateDisabled = $true
        }
    }
}


$AdobeServiceWMI = Get-CimInstance `
    Win32_Service `
    -Filter "Name='AdobeARMservice'" `
    -ErrorAction SilentlyContinue

$TareasAdobe = @(

    Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object {

        $_.TaskName -match "Adobe.*Update|Acrobat.*Update"
    }
)

$TareasAdobeActivas = @(

    $TareasAdobe |
    Where-Object {

        $_.State -ne "Disabled"
    }
)

$MecanismoAdobeEncontrado = (
    $AdobeServiceWMI -or
    $TareasAdobe.Count -gt 0
)

$ServicioAdobeDeshabilitado = (
    -not $AdobeServiceWMI -or
    $AdobeServiceWMI.StartMode -eq "Disabled"
)

$TareasAdobeDeshabilitadas = (
    $TareasAdobe.Count -eq 0 -or
    $TareasAdobeActivas.Count -eq 0
)

if (
    -not $AdobeUpdateDisabled -and
    $MecanismoAdobeEncontrado -and
    $ServicioAdobeDeshabilitado -and
    $TareasAdobeDeshabilitadas
) {

    $AdobeUpdateDisabled = $true
}

$DetalleServicioAdobe = if ($AdobeServiceWMI) {

    "$($AdobeServiceWMI.State)/$($AdobeServiceWMI.StartMode)"

}
else {

    "No encontrado"
}

$DetalleTareasAdobe = if ($TareasAdobe.Count -gt 0) {

    @(
        $TareasAdobe |
        ForEach-Object {

            "$($_.TaskName)=$($_.State)"
        }
    ) -join ", "

}
else {

    "No encontradas"
}

$DetallePoliticaAdobe = if ($PoliticasAdobeEncontradas.Count -gt 0) {

    $PoliticasAdobeEncontradas -join ", "

}
else {

    "bUpdater no configurado"
}

$DetalleAdobeUpdate = (
    "Politica: $DetallePoliticaAdobe | " +
    "Servicio AdobeARMservice: $DetalleServicioAdobe | " +
    "Tareas: $DetalleTareasAdobe"
)


if ($AdobeUpdateDisabled) {

    Agregar-Resultado `
        22 `
        "Actualizacion automatica Adobe deshabilitada" `
        "SI" `
        $DetalleAdobeUpdate

}
elseif (-not $MecanismoAdobeEncontrado) {

    Agregar-Resultado `
        22 `
        "Actualizacion automatica Adobe deshabilitada" `
        "REVISAR" `
        (
            "No se encontraron mecanismos de actualizacion para validar. " +
            $DetalleAdobeUpdate
        )

}
else {

    Agregar-Resultado `
        22 `
        "Actualizacion automatica Adobe deshabilitada" `
        "NO" `
        (
            "Actualizacion habilitada o sin politica de bloqueo. " +
            $DetalleAdobeUpdate
        )

}


# ============================================================
# 23 - HOSTNAME
# ============================================================

Mostrar-Avance 23 "Hostname"

$DNSHostname = [System.Net.Dns]::GetHostName()


if (
    $Hostname -and
    $DNSHostname -eq $Hostname
) {

    Agregar-Resultado `
        23 `
        "HostName" `
        "SI" `
        $Hostname

}
else {

    Agregar-Resultado `
        23 `
        "HostName" `
        "NO" `
        "Windows=$Hostname DNS=$DNSHostname"

}


# ============================================================
# 24 - ONEDRIVE
# ============================================================

Mostrar-Avance 24 "OneDrive (la busqueda en perfiles puede tardar)"

$OneDriveSoftware = Buscar-Software `
    "Microsoft OneDrive"


$OneDriveExe = @(

    Get-ChildItem `
        "C:\Program Files\Microsoft OneDrive",
        "C:\Program Files (x86)\Microsoft OneDrive",
        "C:\Users\*\AppData\Local\Microsoft\OneDrive" `
        -Filter OneDrive.exe `
        -Recurse `
        -ErrorAction SilentlyContinue

) | Select-Object -First 1


if (
    $OneDriveSoftware.Count -gt 0 -or
    $OneDriveExe
) {

    Agregar-Resultado `
        24 `
        "OneDrive" `
        "SI" `
        "OneDrive detectado."

}
else {

    Agregar-Resultado `
        24 `
        "OneDrive" `
        "NO" `
        "OneDrive no detectado."

}


# ============================================================
# 25 - VPN
# ============================================================

Mostrar-Avance 25 "VPN corporativa"

$VPN = Buscar-Software $PatronVPN


if ($VPN.Count -gt 0) {

    Agregar-Resultado `
        25 `
        "VPN" `
        "SI" `
        (
            (
                $VPN |
                ForEach-Object {

                    "$($_.DisplayName) $($_.DisplayVersion)"

                }
            ) -join ", "
        )

}
else {

    Agregar-Resultado `
        25 `
        "VPN" `
        "NO" `
        "VPN corporativa no detectada."

}


# ============================================================
# 26 - RDP
# ============================================================

Mostrar-Avance 26 "Conexion RDP"

$RDP = (

    Get-ItemProperty `
        "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" `
        -Name fDenyTSConnections

).fDenyTSConnections


if ($RDP -eq 0) {

    Agregar-Resultado `
        26 `
        "Conexion RDP" `
        "SI" `
        "RDP habilitado."

}
else {

    Agregar-Resultado `
        26 `
        "Conexion RDP" `
        "NO" `
        "RDP deshabilitado."

}


# ============================================================
# 27 - IMPRESORAS
# ============================================================

Mostrar-Avance 27 "Impresoras"

$Impresoras = @(

    Get-CimInstance Win32_Printer |
    Where-Object {

        $_.Name -notmatch `
        "Microsoft Print to PDF|XPS|Fax|OneNote"

    }

)


if ($Impresoras.Count -gt 0) {

    Agregar-Resultado `
        27 `
        "Impresoras" `
        "SI" `
        (
            ($Impresoras.Name) -join ", "
        )

}
else {

    Agregar-Resultado `
        27 `
        "Impresoras" `
        "NO" `
        "No se detectaron impresoras fisicas/corporativas."

}


# ============================================================
# 28 - CONTENEDOR ACTIVE DIRECTORY
# ============================================================

Mostrar-Avance 28 "Ubicacion en Active Directory"

$DNEquipo = $null


try {

    $RootDSE = [ADSI]"LDAP://RootDSE"

    $NamingContext = `
        $RootDSE.defaultNamingContext


    $Searcher = New-Object `
        System.DirectoryServices.DirectorySearcher


    $Searcher.SearchRoot = `
        [ADSI]("LDAP://" + $NamingContext)


    $SAM = $env:COMPUTERNAME + '$'


    $Searcher.Filter = `
        "(&(objectCategory=computer)(sAMAccountName=$SAM))"


    $Encontrado = $Searcher.FindOne()


    if ($Encontrado) {

        $DNEquipo = `
            $Encontrado.Properties[
                "distinguishedname"
            ][0]
    }

}
catch {}


if ($DNEquipo) {

    $UbicacionAD = $DNEquipo -replace "^[^,]+,", ""
    $PrimerComponenteAD = ($UbicacionAD -split ",")[0]

    if ($PrimerComponenteAD -match "^OU=") {

        $TipoUbicacionAD = "OU"
        $NombreUbicacionAD = $PrimerComponenteAD -replace "^OU=", ""

    }
    elseif ($PrimerComponenteAD -match "^CN=") {

        $TipoUbicacionAD = "Contenedor"
        $NombreUbicacionAD = $PrimerComponenteAD -replace "^CN=", ""

    }
    else {

        $TipoUbicacionAD = "Ruta"
        $NombreUbicacionAD = $PrimerComponenteAD
    }

    if ($OUEsperadaRegex) {

        if ($DNEquipo -match $OUEsperadaRegex) {

            $EstadoOU = "SI"

        }
        else {

            $EstadoOU = "NO"
        }

    }
    else {

        # Sin una OU corporativa especifica, el requisito es:
        # el equipo debe existir en Active Directory y se informa su ubicacion.
        $EstadoOU = "SI"
    }

    $DetalleOU = (
        "Existe en AD | " +
        ("{0}: {1}" -f $TipoUbicacionAD, $NombreUbicacionAD) +
        " | Ruta: $UbicacionAD"
    )

    Agregar-Resultado `
        28 `
        "Existencia y ubicacion en Active Directory" `
        $EstadoOU `
        $DetalleOU

}
else {

    Agregar-Resultado `
        28 `
        "Existencia y ubicacion en Active Directory" `
        "NO" `
        "No fue posible localizar el objeto del equipo en AD."

}


# ============================================================
# 29 - COBIS IMPRESORA / SCANNER
# ============================================================

Mostrar-Avance 29 "COBIS impresora y scanner"

$ServicioCobisDevice = Get-CimInstance `
    Win32_Service `
    -Filter "Name='CobisDeviceServer'" `
    -ErrorAction SilentlyContinue


if (-not $ServicioCobisDevice) {

    Agregar-Resultado `
        29 `
        "Cobis Impresora - Scanner" `
        "NO" `
        "Servicio CobisDeviceServer no instalado."

}
else {

    $RutaCobisDevice = $ServicioCobisDevice.PathName

    if ($RutaCobisDevice -match '^"([^"]+)"') {

        $RutaEjecutableCobisDevice = $Matches[1]

    }
    else {

        $RutaEjecutableCobisDevice = (
            $RutaCobisDevice -split "\s+"
        )[0]
    }

    $EjecutableCobisDeviceExiste = Test-Path `
        $RutaEjecutableCobisDevice

    $VersionCobisDevice = "No detectada"

    $JarPrincipalCobisDevice = @(

        Get-ChildItem `
            -Path (Split-Path $RutaEjecutableCobisDevice) `
            -Filter "cobis-device-server-*.jar" `
            -File `
            -ErrorAction SilentlyContinue |
        Where-Object {

            $_.Name -match
            '^cobis-device-server-\d+(\.\d+)+\.jar$'
        }
    ) |
    Select-Object -First 1


    if (
        $JarPrincipalCobisDevice -and
        $JarPrincipalCobisDevice.Name -match
        '^cobis-device-server-(?<Version>\d+(\.\d+)+)\.jar$'
    ) {

        $VersionCobisDevice = $Matches["Version"]
    }

    $CuentaCobisDeviceCorrecta = (
        $ServicioCobisDevice.StartName -match
        "^(LocalSystem|NT AUTHORITY\\SYSTEM)$"
    )

    $CobisDeviceCumple = (
        $ServicioCobisDevice.State -eq "Running" -and
        $ServicioCobisDevice.StartMode -eq "Auto" -and
        $CuentaCobisDeviceCorrecta -and
        $EjecutableCobisDeviceExiste
    )

    $DetalleCobisDevice = (
        "CobisDeviceServer: {0}/{1} | Version: {2} | " +
        "Cuenta: {3} | Ejecutable: {4} | Ruta: {5}"
    ) -f `
        $ServicioCobisDevice.State,
        $ServicioCobisDevice.StartMode,
        $VersionCobisDevice,
        $ServicioCobisDevice.StartName,
        $EjecutableCobisDeviceExiste,
        $RutaEjecutableCobisDevice


    if (-not $CobisDeviceCumple) {

        $EventosCobisDevice = @(

            Get-WinEvent `
                -FilterHashtable @{
                    LogName      = "System"
                    ProviderName = "Service Control Manager"
                    StartTime    = (Get-Date).AddDays(-7)
                } `
                -MaxEvents 300 `
                -ErrorAction SilentlyContinue |
            Where-Object {

                $_.Id -in 7000, 7009 -and
                $_.Message -match
                "CobisDeviceServer|COBIS Device Server"
            } |
            Sort-Object TimeCreated -Descending
        )


        if ($EventosCobisDevice.Count -gt 0) {

            $UltimoEventoCobisDevice = `
                $EventosCobisDevice |
                Select-Object -First 1

            $DetalleCobisDevice += (
                " | Errores SCM ultimos 7 dias: {0}; " +
                "ultimo ID {1} en {2}"
            ) -f `
                $EventosCobisDevice.Count,
                $UltimoEventoCobisDevice.Id,
                $UltimoEventoCobisDevice.TimeCreated
        }
    }


    Agregar-Resultado `
        29 `
        "Cobis Impresora - Scanner" `
        $(if ($CobisDeviceCumple) { "SI" } else { "NO" }) `
        $DetalleCobisDevice
}


# ============================================================
# 30 - CISCO
# ============================================================

Mostrar-Avance 30 "Software Cisco"

$Cisco = Buscar-Software `
    "^Cisco |Cisco Systems"


if ($Cisco.Count -gt 0) {

    Agregar-Resultado `
        30 `
        "Cisco" `
        "SI" `
        (
            (
                $Cisco |
                ForEach-Object {

                    "$($_.DisplayName) $($_.DisplayVersion)"

                }
            ) -join ", "
        )

}
else {

    Agregar-Resultado `
        30 `
        "Cisco" `
        "NO" `
        "Software Cisco no detectado."

}


# ============================================================
# 31 - COMPONENTES LOCALES COBIS
# ============================================================

Mostrar-Avance 31 "Componentes locales COBIS"

$RutaBaseCobis = "C:\COBIS\DeviceServer"

$ComponentesCobisRequeridos = [ordered]@{

    "Ejecutable 64 bits" = Join-Path `
        $RutaBaseCobis `
        "CobisDeviceServer64.exe"

    "JAR principal" = Join-Path `
        $RutaBaseCobis `
        "cobis-device-server-$VersionCobisAprobada.jar"

    "JAR base" = Join-Path `
        $RutaBaseCobis `
        "cobis-device-server-base-$VersionCobisAprobada.jar"

    "Configuracion" = Join-Path `
        $RutaBaseCobis `
        "config\cobis-device-server.properties"

    "Modulo impresora" = Join-Path `
        $RutaBaseCobis `
        "lib\cobis-printer-api-$VersionCobisAprobada.jar"

    "Modulo scanner" = Join-Path `
        $RutaBaseCobis `
        "lib\cobis-scanner-controller-$VersionCobisAprobada.jar"
}

$ComponentesCobisFaltantes = @(

    $ComponentesCobisRequeridos.GetEnumerator() |
    Where-Object {

        -not (Test-Path $_.Value)

    } |
    ForEach-Object {

        $_.Key
    }
)

$JarPrincipalCobis = @(

    Get-ChildItem `
        -Path $RutaBaseCobis `
        -Filter "cobis-device-server-*.jar" `
        -File `
        -ErrorAction SilentlyContinue |
    Where-Object {

        $_.Name -match
        '^cobis-device-server-\d+(\.\d+)+\.jar$'
    }
) |
Select-Object -First 1

$VersionCobisDetectada = "No detectada"


if (
    $JarPrincipalCobis -and
    $JarPrincipalCobis.Name -match
    '^cobis-device-server-(?<Version>\d+(\.\d+)+)\.jar$'
) {

    $VersionCobisDetectada = $Matches["Version"]
}

$VersionCobisCumple = (
    $VersionCobisDetectada -eq $VersionCobisAprobada
)

$CantidadComponentesCobis = `
    $ComponentesCobisRequeridos.Count

$CantidadPresentesCobis = `
    $CantidadComponentesCobis - `
    $ComponentesCobisFaltantes.Count

$CobisComponentesCumple = (
    $VersionCobisCumple -and
    $ComponentesCobisFaltantes.Count -eq 0
)

$DetalleComponentesCobis = (
    "Version detectada: {0} | Requerida: {1} | " +
    "Componentes: {2}/{3} | Ruta: {4}"
) -f `
    $VersionCobisDetectada,
    $VersionCobisAprobada,
    $CantidadPresentesCobis,
    $CantidadComponentesCobis,
    $RutaBaseCobis


if ($ComponentesCobisFaltantes.Count -gt 0) {

    $DetalleComponentesCobis += (
        " | Faltantes: " +
        ($ComponentesCobisFaltantes -join ", ")
    )
}


Agregar-Resultado `
    31 `
    "COBIS componentes locales" `
    $(if ($CobisComponentesCumple) { "SI" } else { "NO" }) `
    $DetalleComponentesCobis


# ============================================================
# 32 - GLPI INVENTORY / GLPI AGENT
# ============================================================

Mostrar-Avance 32 "GLPI Inventory (GLPI Agent)"

$GLPIAgent = Buscar-Software `
    "^GLPI Agent"

$ServicioGLPI = Get-CimInstance Win32_Service `
    -Filter "Name='glpi-agent'" `
    -ErrorAction SilentlyContinue

$EjecutableGLPI = @(

    Get-ChildItem `
        "C:\Program Files\GLPI-Agent",
        "C:\Program Files (x86)\GLPI-Agent",
        "C:\GLPI" `
        -Filter "glpi-agent.exe" `
        -Recurse `
        -ErrorAction SilentlyContinue

) | Select-Object -First 1


if ($GLPIAgent.Count -gt 0) {

    $DetalleGLPI = @(

        $GLPIAgent |
        ForEach-Object {

            "$($_.DisplayName) $($_.DisplayVersion)"
        }

    ) -join ", "

    if (
        $ServicioGLPI -and
        $ServicioGLPI.State -eq "Running" -and
        $ServicioGLPI.StartMode -eq "Auto"
    ) {

        Agregar-Resultado `
            32 `
            "GLPI Inventory (GLPI Agent)" `
            "SI" `
            (
                "$DetalleGLPI | " +
                "Servicio glpi-agent: Running/Auto"
            )

    }
    else {

        $EstadoServicioGLPI = if ($ServicioGLPI) {

            "$($ServicioGLPI.State)/$($ServicioGLPI.StartMode)"

        }
        else {

            "No encontrado"
        }

        Agregar-Resultado `
            32 `
            "GLPI Inventory (GLPI Agent)" `
            "REVISAR" `
            (
                "$DetalleGLPI | " +
                "Servicio glpi-agent: $EstadoServicioGLPI"
            )
    }

}
elseif ($ServicioGLPI -or $EjecutableGLPI) {

    $EvidenciaGLPI = @()

    if ($ServicioGLPI) {

        $EvidenciaGLPI += (
            "Servicio: $($ServicioGLPI.State)/" +
            "$($ServicioGLPI.StartMode)"
        )
    }

    if ($EjecutableGLPI) {

        $EvidenciaGLPI += (
            "Ejecutable: $($EjecutableGLPI.FullName)"
        )
    }

    Agregar-Resultado `
        32 `
        "GLPI Inventory (GLPI Agent)" `
        "REVISAR" `
        (
            "Se encontro evidencia del agente, pero no su " +
            "registro de instalacion. " +
            ($EvidenciaGLPI -join " | ")
        )

}
else {

    Agregar-Resultado `
        32 `
        "GLPI Inventory (GLPI Agent)" `
        "NO" `
        "GLPI Agent no detectado."

}


# ============================================================
# MOSTRAR CABECERA
# ============================================================

Write-Host "[32/32] 100% - Validaciones terminadas. Generando reporte..." -ForegroundColor Green

Write-Host ""
Write-Host "=============================================================="
Write-Host " CERTIFICACION TECNICA DE EQUIPO"
Write-Host " COLTEFINANCIERA - N1"
Write-Host "=============================================================="
Write-Host ""

Write-Host "Equipo        : $Hostname"
Write-Host "Usuario       : $UsuarioActual"
Write-Host "Fabricante    : $($CS.Manufacturer)"
Write-Host "Modelo        : $($CS.Model)"
Write-Host "Serial        : $($BIOS.SerialNumber)"
Write-Host "Windows       : $($OS.Caption)"
Write-Host "Version       : $($OS.Version)"
Write-Host "Build         : $($OS.BuildNumber)"
Write-Host "Dominio       : $($CS.Domain)"
Write-Host "Fecha checker : $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')"

Write-Host ""
Write-Host "=============================================================="
Write-Host " RESULTADOS"
Write-Host "=============================================================="
Write-Host ""


# ============================================================
# MOSTRAR RESULTADOS
# ============================================================

$Resultados |
    Sort-Object Numero |
    Format-Table `
        Numero,
        Control,
        Estado,
        Detalle `
        -AutoSize `
        -Wrap


# ============================================================
# RESUMEN
# ============================================================

$TotalSI = @(

    $Resultados |
    Where-Object {

        $_.Estado -eq "SI"

    }

).Count


$TotalNO = @(

    $Resultados |
    Where-Object {

        $_.Estado -eq "NO"

    }

).Count


$TotalRevisar = @(

    $Resultados |
    Where-Object {

        $_.Estado -eq "REVISAR"

    }

).Count


Write-Host ""
Write-Host "=============================================================="
Write-Host " RESUMEN"
Write-Host "=============================================================="
Write-Host ""

Write-Host "Cumple       : $TotalSI"
Write-Host "No cumple    : $TotalNO"
Write-Host "Por revisar  : $TotalRevisar"
Write-Host "Total        : $($Resultados.Count)"
Write-Host ""


if ($TotalNO -eq 0 -and $TotalRevisar -eq 0) {

    $EstadoGeneral = "CERTIFICADO"

}
elseif ($TotalNO -eq 0) {

    $EstadoGeneral = "PENDIENTE DE VALIDACION"

}
else {

    $EstadoGeneral = "NO CERTIFICADO"
}

Write-Host "ESTADO GENERAL: $EstadoGeneral"


Write-Host ""
Write-Host "=============================================================="
Write-Host " CONTROLES QUE NO CUMPLEN"
Write-Host "=============================================================="
Write-Host ""


$Resultados |
    Where-Object {

        $_.Estado -eq "NO"

    } |
    ForEach-Object {

        Write-Host (
            "[{0}] {1}" -f
            $_.Numero,
            $_.Control
        )

        Write-Host (
            "    {0}" -f
            $_.Detalle
        )

        Write-Host ""
    }

Write-Host "=============================================================="
Write-Host " CONTROLES PENDIENTES DE REVISION"
Write-Host "=============================================================="
Write-Host ""


if ($TotalRevisar -eq 0) {

    Write-Host "Ninguno."
    Write-Host ""

}
else {

    $Resultados |
        Where-Object {

            $_.Estado -eq "REVISAR"

        } |
        ForEach-Object {

            Write-Host (
                "[{0}] {1}" -f
                $_.Numero,
                $_.Control
            )

            Write-Host (
                "    {0}" -f
                $_.Detalle
            )

            Write-Host ""
        }
}


Write-Host "=============================================================="
Write-Host " FIN DEL CHECKER"
Write-Host "=============================================================="
Write-Host ""


# ============================================================
# GENERAR REPORTE HTML
# ============================================================

function Convertir-AHtmlSeguro {

    param(

        [object]$Valor
    )

    return [System.Net.WebUtility]::HtmlEncode(
        [string]$Valor
    )
}


if ([string]::IsNullOrWhiteSpace($RutaReporteHtml)) {

    $CarpetaReporteHtml = Join-Path `
        $PSScriptRoot `
        "Reportes"

    $NombreReporteHtml = (
        "{0}_Checker_{1}.html" -f
        $Hostname,
        (Get-Date -Format "yyyyMMdd_HHmmss")
    )

    $RutaReporteHtml = Join-Path `
        $CarpetaReporteHtml `
        $NombreReporteHtml

}
else {

    $CarpetaReporteHtml = Split-Path `
        -Parent `
        $RutaReporteHtml


    if ([string]::IsNullOrWhiteSpace($CarpetaReporteHtml)) {

        $CarpetaReporteHtml = (Get-Location).Path
        $RutaReporteHtml = Join-Path `
            $CarpetaReporteHtml `
            $RutaReporteHtml
    }
}


if (-not (Test-Path $CarpetaReporteHtml)) {

    New-Item `
        -Path $CarpetaReporteHtml `
        -ItemType Directory `
        -Force `
        -ErrorAction Stop |
    Out-Null
}

$TotalResultados = $Resultados.Count
$PorcentajeCumplimiento = if ($TotalResultados -gt 0) {

    [Math]::Round(
        ($TotalSI / $TotalResultados) * 100,
        1
    )

}
else {

    0
}

$ClaseEstadoGeneral = switch ($EstadoGeneral) {

    "CERTIFICADO" {

        "certificado"
        break
    }

    "PENDIENTE DE VALIDACION" {

        "pendiente"
        break
    }

    default {

        "no-certificado"
    }
}

$FilasResultadosHtml = @(

    $Resultados |
    Sort-Object Numero |
    ForEach-Object {

        $ClaseEstado = switch ($_.Estado) {

            "SI" { "si"; break }
            "NO" { "no"; break }
            default { "revisar" }
        }

        $DetalleSeguro = Convertir-AHtmlSeguro $_.Detalle
        $DetalleSeguro = $DetalleSeguro -replace `
            "[\r\n]+", `
            "<br>"

        @"
<tr>
    <td class="numero">$(Convertir-AHtmlSeguro $_.Numero)</td>
    <td class="control">$(Convertir-AHtmlSeguro $_.Control)</td>
    <td><span class="estado $ClaseEstado">$(Convertir-AHtmlSeguro $_.Estado)</span></td>
    <td class="detalle">$DetalleSeguro</td>
</tr>
"@
    }
) -join "`r`n"

$RecomendacionesControles = @{

    1  = "Verificar que el agente corporativo este instalado, actualizado y con sus servicios activos."
    2  = "Instalar o reparar Safetica y confirmar STCService en ejecucion con inicio automatico."
    3  = "Habilitar BitLocker y respaldar la clave de recuperacion antes de certificar."
    4  = "Retirar del grupo Administradores las cuentas o grupos no autorizados."
    5  = "Retirar miembros del grupo Usuarios avanzados salvo autorizacion documentada."
    6  = "Deshabilitar o retirar cuentas locales adicionales que no tengan justificacion vigente."
    7  = "Exigir clave a las cuentas administradoras locales y gestionar su rotacion mediante LAPS o la politica corporativa."
    8  = "Instalar las actualizaciones pendientes y validar nuevamente despues del reinicio programado."
    9  = "Habilitar los perfiles Domain, Private y Public mediante la politica corporativa."
    10 = "Eliminar los recursos compartidos no autorizados o documentar su necesidad."
    11 = "Reparar la activacion de Microsoft 365 y comprobar el estado Licensed con vNextDiag."
    12 = "Aplicar RestrictAnonymous=1 y conservar bloqueadas las sesiones y los recursos nulos."
    13 = "Instalar Adobe Acrobat o Reader aprobado por la organizacion."
    14 = "Instalar UltraVNC aprobado y validar su configuracion de acceso."
    15 = "Instalar Oracle Java 8 Update 411 de 64 bits y comprobar el resultado de java -version."
    16 = "Instalar la version corporativa aprobada de 7-Zip."
    17 = "Instalar PDFCreator y confirmar que la impresora virtual quede disponible."
    18 = "Habilitar Secure Boot en UEFI y confirmar TPM 2.0 listo; respaldar antes la clave de BitLocker."
    19 = "Configurar TcpipNetbiosOptions=2 en los adaptadores activos y validar la conectividad."
    20 = "Habilitar Wake on Magic Packet en el adaptador y, si aplica, en BIOS o UEFI."
    21 = "Aplicar EnableJavaUpdate=0 en la ruta de politica y deshabilitar el programador de actualizaciones."
    22 = "Aplicar bUpdater=0 y deshabilitar el servicio o tarea de actualizacion segun la politica corporativa."
    23 = "Corregir el nombre del equipo conforme al estandar antes de unirlo o actualizarlo en Active Directory."
    24 = "Instalar o reparar OneDrive y completar el inicio de sesion corporativo."
    25 = "Instalar FortiClient VPN corporativo y validar su perfil de conexion."
    26 = "Habilitar RDP mediante una politica autorizada y verificar las reglas de firewall."
    27 = "Instalar y probar las impresoras corporativas requeridas para la sede y el usuario."
    28 = "Crear o mover el objeto del equipo a la unidad organizativa autorizada de Active Directory."
    29 = "Reparar CobisDeviceServer, configurarlo en inicio automatico y resolver los eventos 7000 o 7009."
    30 = "Instalar Cisco Jabber u otro cliente Cisco corporativo aprobado."
    31 = "Reinstalar COBIS Device Server 7.7.4 para recuperar los componentes locales faltantes."
    32 = "Instalar o reparar GLPI Agent y dejar el servicio glpi-agent en estado Running y modo Auto."
}

$ControlesNoHtml = @(

    $Resultados |
    Where-Object {

        $_.Estado -eq "NO"

    } |
    Sort-Object Numero |
    ForEach-Object {

        $Recomendacion = $RecomendacionesControles[[int]$_.Numero]

        if (-not $Recomendacion) {

            $Recomendacion = "Revisar la configuracion de este control y aplicar la politica corporativa correspondiente."
        }

        $DetalleSeguro = Convertir-AHtmlSeguro $_.Detalle
        $RecomendacionSegura = Convertir-AHtmlSeguro $Recomendacion

        @"
<article class="hallazgo hallazgo-no">
    <div class="hallazgo-numero">$($_.Numero)</div>
    <div>
        <h3>$(Convertir-AHtmlSeguro $_.Control)</h3>
        <p class="evidencia">$DetalleSeguro</p>
        <div class="recomendacion">
            <svg class="icono" aria-hidden="true"><use href="#icon-lightbulb"></use></svg>
            <div>
                <span>Recomendacion</span>
                <p>$RecomendacionSegura</p>
            </div>
        </div>
    </div>
</article>
"@
    }
)


if ($ControlesNoHtml.Count -eq 0) {

    $ControlesNoHtml = @(
        '<p class="sin-hallazgos">No existen controles incumplidos.</p>'
    )
}

$ControlesRevisarHtml = @(

    $Resultados |
    Where-Object {

        $_.Estado -eq "REVISAR"

    } |
    Sort-Object Numero |
    ForEach-Object {

        @"
<article class="hallazgo hallazgo-revisar">
    <div class="hallazgo-numero">$($_.Numero)</div>
    <div>
        <h3>$(Convertir-AHtmlSeguro $_.Control)</h3>
        <p>$(Convertir-AHtmlSeguro $_.Detalle)</p>
    </div>
</article>
"@
    }
)


if ($ControlesRevisarHtml.Count -eq 0) {

    $ControlesRevisarHtml = @(
        '<p class="sin-hallazgos">No existen controles pendientes de revision.</p>'
    )
}

$FechaReporteHtml = Get-Date -Format `
    "yyyy-MM-dd HH:mm:ss"

$HtmlReporte = @"
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Certificacion tecnica - $(Convertir-AHtmlSeguro $Hostname)</title>
    <style>
        :root {
            --azul: #0b3f70;
            --azul-medio: #176aa6;
            --azul-claro: #eaf3fb;
            --fondo: #f2f5f9;
            --texto: #172033;
            --muted: #667085;
            --borde: #d9e2ec;
            --verde: #137a4b;
            --verde-fondo: #e7f7ef;
            --rojo: #b42318;
            --rojo-fondo: #feeceb;
            --amarillo: #8a5a00;
            --amarillo-fondo: #fff4d6;
        }
        * { box-sizing: border-box; }
        body {
            margin: 0;
            background: var(--fondo);
            color: var(--texto);
            font-family: "Segoe UI", Arial, sans-serif;
            font-size: 14px;
            line-height: 1.45;
        }
        .icon-sprite {
            position: absolute;
            width: 0;
            height: 0;
            overflow: hidden;
        }
        .icono {
            width: 20px;
            height: 20px;
            fill: none;
            stroke: currentColor;
            stroke-width: 1.9;
            stroke-linecap: round;
            stroke-linejoin: round;
            flex: 0 0 auto;
        }
        .contenedor {
            width: min(1180px, calc(100% - 32px));
            margin: 28px auto 48px;
        }
        .encabezado {
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 24px;
            position: relative;
            overflow: hidden;
            padding: 30px;
            color: white;
            background: linear-gradient(125deg, var(--azul) 0%, var(--azul-medio) 100%);
            border-radius: 18px;
            box-shadow: 0 14px 34px rgba(11, 63, 112, .2);
        }
        .encabezado::after {
            content: "";
            position: absolute;
            right: -72px;
            top: -105px;
            width: 280px;
            height: 280px;
            border: 48px solid rgba(255,255,255,.06);
            border-radius: 50%;
        }
        .identidad, .resumen-hero { position: relative; z-index: 1; }
        .identidad { display: flex; align-items: center; gap: 16px; }
        .sello {
            width: 58px;
            height: 58px;
            display: grid;
            place-items: center;
            flex: 0 0 auto;
            color: var(--azul);
            background: white;
            border-radius: 15px;
            font-size: 19px;
            font-weight: 900;
            letter-spacing: -.04em;
            box-shadow: 0 8px 22px rgba(0,0,0,.12);
        }
        .encabezado h1 { margin: 3px 0 3px; font-size: 28px; line-height: 1.15; }
        .subtitulo { margin: 0; opacity: .86; font-size: 13px; }
        .marca { font-size: 12px; font-weight: 750; letter-spacing: .09em; opacity: .88; }
        .resumen-hero { display: flex; align-items: stretch; gap: 12px; }
        .equipo-hero {
            min-width: 160px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding: 12px 16px;
            border: 1px solid rgba(255,255,255,.22);
            border-radius: 13px;
            background: rgba(255,255,255,.1);
        }
        .equipo-hero span { font-size: 11px; opacity: .8; text-transform: uppercase; letter-spacing: .06em; }
        .equipo-hero strong { margin-top: 2px; font-size: 16px; overflow-wrap: anywhere; }
        .estado-general {
            min-width: 190px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 9px;
            padding: 13px 17px;
            border: 1px solid rgba(255,255,255,.25);
            border-radius: 13px;
            text-align: center;
            font-size: 15px;
            font-weight: 800;
            background: rgba(255,255,255,.12);
        }
        .estado-general .icono { width: 22px; height: 22px; }
        .estado-general.certificado { background: rgba(19,122,75,.9); }
        .estado-general.no-certificado { background: rgba(180,35,24,.92); }
        .estado-general.pendiente { background: rgba(138,90,0,.92); }
        .tarjetas {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
            margin: 18px 0;
        }
        .tarjeta, .panel {
            background: white;
            border: 1px solid var(--borde);
            border-radius: 14px;
            box-shadow: 0 3px 14px rgba(16,24,40,.05);
        }
        .tarjeta { display: flex; align-items: center; gap: 13px; min-height: 102px; padding: 17px; }
        .tarjeta > div:last-child { min-width: 0; flex: 1; }
        .icono-resumen {
            width: 44px;
            height: 44px;
            display: grid;
            place-items: center;
            flex: 0 0 auto;
            color: var(--azul);
            background: var(--azul-claro);
            border-radius: 12px;
        }
        .icono-resumen .icono { width: 23px; height: 23px; }
        .tarjeta .valor { display: block; font-size: 28px; font-weight: 800; }
        .tarjeta .etiqueta { display: block; color: var(--muted); font-size: 12px; }
        .tarjeta.cumple .valor { color: var(--verde); }
        .tarjeta.cumple .icono-resumen { color: var(--verde); background: var(--verde-fondo); }
        .tarjeta.no-cumple .valor { color: var(--rojo); }
        .tarjeta.no-cumple .icono-resumen { color: var(--rojo); background: var(--rojo-fondo); }
        .tarjeta.revisar .valor { color: var(--amarillo); }
        .tarjeta.revisar .icono-resumen { color: var(--amarillo); background: var(--amarillo-fondo); }
        .panel { margin-top: 18px; overflow: hidden; }
        .panel-titulo {
            display: flex;
            align-items: center;
            gap: 10px;
            margin: 0;
            padding: 18px 22px;
            color: var(--azul);
            font-size: 18px;
            border-bottom: 1px solid var(--borde);
        }
        .panel-titulo .icono { width: 21px; height: 21px; }
        .datos-equipo {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 0;
            padding: 8px 20px 20px;
        }
        .dato { display: flex; align-items: center; gap: 11px; min-width: 0; padding: 13px 8px; border-bottom: 1px solid #edf1f5; }
        .dato > div:last-child { min-width: 0; }
        .icono-dato {
            width: 36px;
            height: 36px;
            display: grid;
            place-items: center;
            flex: 0 0 auto;
            color: var(--azul-medio);
            background: var(--azul-claro);
            border-radius: 10px;
        }
        .icono-dato .icono { width: 19px; height: 19px; }
        .dato span { display: block; color: var(--muted); font-size: 12px; }
        .dato strong { display: block; margin-top: 3px; overflow-wrap: anywhere; }
        .barra { height: 9px; margin-top: 12px; overflow: hidden; border-radius: 8px; background: #e8edf3; }
        .barra > div { height: 100%; background: var(--verde); }
        .tabla-contenedor { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; }
        th {
            padding: 12px;
            color: #344054;
            background: #f8fafc;
            border-bottom: 1px solid var(--borde);
            text-align: left;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .04em;
        }
        td { padding: 12px; border-bottom: 1px solid #edf1f5; vertical-align: top; }
        tr:last-child td { border-bottom: 0; }
        .numero { width: 58px; text-align: center; color: var(--muted); }
        .control { min-width: 230px; font-weight: 650; }
        .detalle { min-width: 360px; color: #475467; overflow-wrap: anywhere; }
        .estado {
            display: inline-block;
            min-width: 72px;
            padding: 5px 9px;
            border-radius: 999px;
            text-align: center;
            font-size: 12px;
            font-weight: 800;
        }
        .estado.si { color: var(--verde); background: var(--verde-fondo); }
        .estado.no { color: var(--rojo); background: var(--rojo-fondo); }
        .estado.revisar { color: var(--amarillo); background: var(--amarillo-fondo); }
        .hallazgos { padding: 8px 20px 20px; }
        .hallazgo { display: grid; grid-template-columns: 38px 1fr; gap: 12px; padding: 17px 0; border-bottom: 1px solid #edf1f5; }
        .hallazgo:last-child { border-bottom: 0; }
        .hallazgo-numero { width: 34px; height: 34px; display: grid; place-items: center; border-radius: 50%; font-weight: 800; }
        .hallazgo-no .hallazgo-numero { color: var(--rojo); background: var(--rojo-fondo); }
        .hallazgo-revisar .hallazgo-numero { color: var(--amarillo); background: var(--amarillo-fondo); }
        .hallazgo h3 { margin: 1px 0 4px; font-size: 15px; }
        .hallazgo p { margin: 0; color: #475467; overflow-wrap: anywhere; }
        .evidencia::before { content: "Evidencia: "; color: var(--muted); font-size: 12px; font-weight: 700; }
        .recomendacion {
            display: flex;
            gap: 10px;
            margin-top: 11px;
            padding: 11px 13px;
            color: #7a3e00;
            background: #fff8e8;
            border: 1px solid #f4d38b;
            border-radius: 10px;
        }
        .recomendacion .icono { margin-top: 1px; }
        .recomendacion span { display: block; margin-bottom: 2px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: .05em; }
        .recomendacion p { color: #68400f; }
        .sin-hallazgos { margin: 0; padding: 8px 0; color: var(--verde); font-weight: 650; }
        footer { padding: 24px 4px 0; color: var(--muted); text-align: center; font-size: 11px; letter-spacing: .01em; }
        @media (max-width: 800px) {
            .encabezado { flex-direction: column; align-items: stretch; }
            .resumen-hero { width: 100%; }
            .equipo-hero, .estado-general { flex: 1; }
            .tarjetas, .datos-equipo { grid-template-columns: repeat(2, 1fr); }
        }
        @media (max-width: 520px) {
            .contenedor { width: min(calc(100% - 18px), 1180px); margin-top: 10px; }
            .encabezado { padding: 22px; }
            .identidad { align-items: flex-start; }
            .sello { width: 48px; height: 48px; }
            .encabezado h1 { font-size: 23px; }
            .resumen-hero { flex-direction: column; }
            .tarjetas, .datos-equipo { grid-template-columns: 1fr; }
        }
        @media print {
            body { background: white; }
            .contenedor { width: 100%; margin: 0; }
            .encabezado, .tarjeta, .panel { box-shadow: none; }
            .panel { break-inside: avoid; }
        }
    </style>
</head>
<body>
<svg class="icon-sprite" aria-hidden="true">
    <symbol id="icon-check" viewBox="0 0 24 24"><path d="M20 6 9 17l-5-5"></path></symbol>
    <symbol id="icon-x" viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"></path></symbol>
    <symbol id="icon-clock" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M12 7v5l3 2"></path></symbol>
    <symbol id="icon-chart" viewBox="0 0 24 24"><path d="M5 20V10M12 20V4M19 20v-7M3 20h18"></path></symbol>
    <symbol id="icon-monitor" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="13" rx="2"></rect><path d="M8 21h8M12 17v4"></path></symbol>
    <symbol id="icon-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"></circle><path d="M4 21c.8-4 3.5-6 8-6s7.2 2 8 6"></path></symbol>
    <symbol id="icon-building" viewBox="0 0 24 24"><path d="M4 21V6l8-3 8 3v15M2 21h20M8 8h2M14 8h2M8 12h2M14 12h2M8 16h2M14 16h2"></path></symbol>
    <symbol id="icon-laptop" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="12" rx="2"></rect><path d="M2 20h20M9 20h6"></path></symbol>
    <symbol id="icon-tag" viewBox="0 0 24 24"><path d="M20 13 13 20 4 11V4h7l9 9Z"></path><circle cx="8.5" cy="8.5" r="1"></circle></symbol>
    <symbol id="icon-windows" viewBox="0 0 24 24"><path d="M3 5.5 10 4v7H3V5.5ZM12 3.7 21 2v9h-9V3.7ZM3 13h7v7l-7-1.5V13ZM12 13h9v9l-9-1.7V13Z"></path></symbol>
    <symbol id="icon-layers" viewBox="0 0 24 24"><path d="m12 3 9 5-9 5-9-5 9-5Z"></path><path d="m3 12 9 5 9-5M3 16l9 5 9-5"></path></symbol>
    <symbol id="icon-globe" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"></path></symbol>
    <symbol id="icon-shield" viewBox="0 0 24 24"><path d="M12 3 20 6v6c0 5-3.3 8-8 9-4.7-1-8-4-8-9V6l8-3Z"></path><path d="m8.5 12 2.2 2.2 4.8-5"></path></symbol>
    <symbol id="icon-list" viewBox="0 0 24 24"><path d="M9 6h11M9 12h11M9 18h11M4 6h.01M4 12h.01M4 18h.01"></path></symbol>
    <symbol id="icon-lightbulb" viewBox="0 0 24 24"><path d="M9 18h6M10 22h4M8.5 15.5C6.9 14.4 6 12.6 6 10.5a6 6 0 1 1 12 0c0 2.1-.9 3.9-2.5 5-.7.5-1 1.1-1 2.5h-5c0-1.4-.3-2-1-2.5Z"></path></symbol>
</svg>
<main class="contenedor">
    <header class="encabezado">
        <div class="identidad">
            <div class="sello">CF</div>
            <div>
                <div class="marca">COLTEFINANCIERA &middot; CELULA OPERATIVA N1</div>
                <h1>Certificacion tecnica de equipo</h1>
                <p class="subtitulo">Evaluacion de seguridad, software y configuracion</p>
            </div>
        </div>
        <div class="resumen-hero">
            <div class="equipo-hero">
                <span>Equipo evaluado</span>
                <strong>$(Convertir-AHtmlSeguro $Hostname)</strong>
            </div>
            <div class="estado-general $ClaseEstadoGeneral">
                <svg class="icono" aria-hidden="true"><use href="#icon-shield"></use></svg>
                <span>$(Convertir-AHtmlSeguro $EstadoGeneral)</span>
            </div>
        </div>
    </header>

    <section class="tarjetas">
        <div class="tarjeta cumple">
            <div class="icono-resumen"><svg class="icono" aria-hidden="true"><use href="#icon-check"></use></svg></div>
            <div><span class="valor">$TotalSI</span><span class="etiqueta">Controles que cumplen</span></div>
        </div>
        <div class="tarjeta no-cumple">
            <div class="icono-resumen"><svg class="icono" aria-hidden="true"><use href="#icon-x"></use></svg></div>
            <div><span class="valor">$TotalNO</span><span class="etiqueta">Controles que no cumplen</span></div>
        </div>
        <div class="tarjeta revisar">
            <div class="icono-resumen"><svg class="icono" aria-hidden="true"><use href="#icon-clock"></use></svg></div>
            <div><span class="valor">$TotalRevisar</span><span class="etiqueta">Pendientes de revision</span></div>
        </div>
        <div class="tarjeta">
            <div class="icono-resumen"><svg class="icono" aria-hidden="true"><use href="#icon-chart"></use></svg></div>
            <div><span class="valor">$PorcentajeCumplimiento%</span><span class="etiqueta">Cumplimiento total</span><div class="barra"><div style="width: $PorcentajeCumplimiento%"></div></div></div>
        </div>
    </section>

    <section class="panel">
        <h2 class="panel-titulo"><svg class="icono" aria-hidden="true"><use href="#icon-monitor"></use></svg>Informacion del equipo</h2>
        <div class="datos-equipo">
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-monitor"></use></svg></div><div><span>Equipo</span><strong>$(Convertir-AHtmlSeguro $Hostname)</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-user"></use></svg></div><div><span>Usuario</span><strong>$(Convertir-AHtmlSeguro $UsuarioActual)</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-building"></use></svg></div><div><span>Fabricante</span><strong>$(Convertir-AHtmlSeguro $CS.Manufacturer)</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-laptop"></use></svg></div><div><span>Modelo</span><strong>$(Convertir-AHtmlSeguro $CS.Model)</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-tag"></use></svg></div><div><span>Serial</span><strong>$(Convertir-AHtmlSeguro $BIOS.SerialNumber)</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-windows"></use></svg></div><div><span>Windows</span><strong>$(Convertir-AHtmlSeguro $OS.Caption)</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-layers"></use></svg></div><div><span>Version / build</span><strong>$(Convertir-AHtmlSeguro "$($OS.Version) / $($OS.BuildNumber)")</strong></div></div>
            <div class="dato"><div class="icono-dato"><svg class="icono" aria-hidden="true"><use href="#icon-globe"></use></svg></div><div><span>Dominio</span><strong>$(Convertir-AHtmlSeguro $CS.Domain)</strong></div></div>
        </div>
    </section>

    <section class="panel">
        <h2 class="panel-titulo"><svg class="icono" aria-hidden="true"><use href="#icon-list"></use></svg>Resultados de los 32 controles</h2>
        <div class="tabla-contenedor">
            <table>
                <thead><tr><th>#</th><th>Control</th><th>Estado</th><th>Detalle</th></tr></thead>
                <tbody>$FilasResultadosHtml</tbody>
            </table>
        </div>
    </section>

    <section class="panel">
        <h2 class="panel-titulo"><svg class="icono" aria-hidden="true"><use href="#icon-x"></use></svg>Controles que no cumplen</h2>
        <div class="hallazgos">$($ControlesNoHtml -join "`r`n")</div>
    </section>

    <section class="panel">
        <h2 class="panel-titulo"><svg class="icono" aria-hidden="true"><use href="#icon-clock"></use></svg>Controles pendientes de revision</h2>
        <div class="hallazgos">$($ControlesRevisarHtml -join "`r`n")</div>
    </section>

    <footer>
        Generado el $(Convertir-AHtmlSeguro $FechaReporteHtml) &middot; Equipo $(Convertir-AHtmlSeguro $Hostname) &middot; Checker-PC v$(Convertir-AHtmlSeguro $VersionChecker) &middot; Coltefinanciera N1
    </footer>
</main>
</body>
</html>
"@

$HtmlReporte | Set-Content `
    -Path $RutaReporteHtml `
    -Encoding UTF8 `
    -Force `
    -ErrorAction Stop

Write-Host (
    "[REPORTE] HTML guardado en: {0}" -f
    $RutaReporteHtml
) -ForegroundColor Green
